// N3LogicParser.ts
// Parses N3/N3Logic documents into triples, rules, and built-ins (npm package version)
import { N3LogicDocument, N3Triple, N3Rule, N3Builtin, N3Formula, N3Quantifier, N3Term, N3Variable, N3Literal, N3BlankNode, N3IRI, N3List, N3ForAll, N3Exists } from './N3LogicTypes';

export class N3LogicParser {
  parse(n3Text: string): N3LogicDocument {
    // Remove comments and normalize whitespace
    const cleaned = n3Text.replace(/#[^\n]*/g, '').replace(/\s+/g, ' ').trim();
    return {
      triples: this.parseTriples(cleaned),
      rules: this.parseRules(cleaned),
      builtins: this.parseBuiltins(cleaned)
    };
  }

  // Parse triples, supporting literals, variables, lists, blank nodes
  private parseTriples(n3Text: string): N3Triple[] {
    const triples: N3Triple[] = [];
    // Match triples inside formulas or at top level
    const tripleRegex = /([\w:?_\-\[\]"'<>{}\.\,\(\)\^\$\@\!\*\+\/\\]+)\s+([\w:?_\-\[\]"'<>{}\.\,\(\)\^\$\@\!\*\+\/\\]+)\s+([\w:?_\-\[\]"'<>{}\.\,\(\)\^\$\@\!\*\+\/\\]+)\s*\./g;
    let match;
    while ((match = tripleRegex.exec(n3Text)) !== null) {
      triples.push({
        subject: this.parseTerm(match[1]),
        predicate: this.parseTerm(match[2]),
        object: this.parseTerm(match[3])
      });
    }
    return triples;
  }

  // Parse a term: IRI, literal, variable, blank node, list
  private parseTerm(token: string): N3Term {
    token = token.trim();
    if (token.startsWith('<') && token.endsWith('>')) {
      return { type: 'IRI', value: token.slice(1, -1) } as N3IRI;
    } else if (token.startsWith('"')) {
      // Literal with optional datatype or language
      const litMatch = token.match(/^"([^"]*)"(?:\^\^<([^>]+)>|@([a-zA-Z\-]+))?/);
      if (litMatch) {
        return {
          type: 'Literal',
          value: litMatch[1],
          datatype: litMatch[2],
          language: litMatch[3]
        } as N3Literal;
      }
    } else if (token.startsWith('?')) {
      return { type: 'Variable', value: token.slice(1) } as N3Variable;
    } else if (token.startsWith('_:')) {
      return { type: 'BlankNode', value: token.slice(2) } as N3BlankNode;
    } else if (token.startsWith('(') && token.endsWith(')')) {
      // List: (a b c)
      const elements = token.slice(1, -1).split(/\s+/).map(t => this.parseTerm(t));
      return { type: 'List', elements } as N3List;
    }
    // Fallback: treat as IRI or string
    return { type: 'IRI', value: token } as N3IRI;
  }

  // Parse rules, supporting nested formulas and quantifiers
  private parseRules(n3Text: string): N3Rule[] {
    const rules: N3Rule[] = [];
    // Match { ... } => { ... } .
    const ruleRegex = /\{([^}]*)\}\s*=>\s*\{([^}]*)\}\s*\./g;
    let match;
    while ((match = ruleRegex.exec(n3Text)) !== null) {
      const antecedent = this.parseFormula(match[1]);
      const consequent = this.parseFormula(match[2]);
      rules.push({
        type: 'Rule',
        antecedent,
        consequent
      });
    }
    // Quantifiers: ForAll, Exists (simple support)
    const forallRegex = /@forAll\s+((?:\?[\w]+\s*)+)\./g;
    while ((match = forallRegex.exec(n3Text)) !== null) {
      // Not directly attached to rules, but can be used for context
      // (Advanced: attach to formulas if needed)
    }
    const existsRegex = /@forSome\s+((?:\?[\w]+\s*)+)\./g;
    while ((match = existsRegex.exec(n3Text)) !== null) {
      // Not directly attached to rules, but can be used for context
    }
    return rules;
  }

  // Parse a formula (set of triples, possibly with quantifiers)
  private parseFormula(text: string): N3Formula {
    // Support for nested formulas and quantifiers is basic here
    const triples = this.parseTriples(text);
    // Quantifier detection (simple)
    const quantifiers: N3Quantifier[] = [];
    const forallRegex = /@forAll\s+((?:\?[\w]+\s*)+)\./g;
    let match;
    while ((match = forallRegex.exec(text)) !== null) {
      const vars = match[1].trim().split(/\s+/).map(v => ({ type: 'Variable', value: v.replace(/^\?/, '') } as N3Variable));
      quantifiers.push({ type: 'ForAll', variables: vars, formula: { type: 'Formula', triples } } as N3ForAll);
    }
    const existsRegex = /@forSome\s+((?:\?[\w]+\s*)+)\./g;
    while ((match = existsRegex.exec(text)) !== null) {
      const vars = match[1].trim().split(/\s+/).map(v => ({ type: 'Variable', value: v.replace(/^\?/, '') } as N3Variable));
      quantifiers.push({ type: 'Exists', variables: vars, formula: { type: 'Formula', triples } } as N3Exists);
    }
    return { type: 'Formula', triples, quantifiers: quantifiers.length ? quantifiers : undefined };
  }

  // Parse builtins (as before)
  private parseBuiltins(n3Text: string): N3Builtin[] {
    const builtins: N3Builtin[] = [];
    const builtinUris = [
      'http://www.w3.org/2000/10/swap/math#greaterThan',
      'http://www.w3.org/2000/10/swap/math#lessThan',
      'http://www.w3.org/2000/10/swap/string#concatenation',
      'http://www.w3.org/2000/10/swap/log#implies',
    ];
    for (const uri of builtinUris) {
      if (n3Text.includes(`<${uri}>`)) {
        builtins.push({
          uri,
          arity: 2,
          apply: () => { throw new Error('Built-in not implemented'); },
          description: 'Stub built-in'
        });
      }
    }
    return builtins;
  }
}
