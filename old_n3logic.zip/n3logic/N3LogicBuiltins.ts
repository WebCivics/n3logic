// --- Additional Math Builtins ---
  {
    uri: 'http://www.w3.org/2000/10/swap/math#abs',
    arity: 1,
    description: 'math:abs(x) returns the absolute value of x',
    apply: (x) => ({ type: 'Literal', value: String(Math.abs(Number(getValue(x)))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#power',
    arity: 2,
    description: 'math:power(x, y) returns x^y',
    apply: (x, y) => ({ type: 'Literal', value: String(Math.pow(Number(getValue(x)), Number(getValue(y)))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#modulo',
    arity: 2,
    description: 'math:modulo(x, y) returns x % y',
    apply: (x, y) => ({ type: 'Literal', value: String(Number(getValue(x)) % Number(getValue(y))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#floor',
    arity: 1,
    description: 'math:floor(x) returns the largest integer <= x',
    apply: (x) => ({ type: 'Literal', value: String(Math.floor(Number(getValue(x)))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#ceil',
    arity: 1,
    description: 'math:ceil(x) returns the smallest integer >= x',
    apply: (x) => ({ type: 'Literal', value: String(Math.ceil(Number(getValue(x)))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#round',
    arity: 1,
    description: 'math:round(x) returns the nearest integer to x',
    apply: (x) => ({ type: 'Literal', value: String(Math.round(Number(getValue(x)))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#negation',
    arity: 1,
    description: 'math:negation(x) returns -x',
    apply: (x) => ({ type: 'Literal', value: String(-Number(getValue(x))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#integer',
    arity: 1,
    description: 'math:integer(x) is true if x is an integer',
    apply: (x) => Number.isInteger(Number(getValue(x)))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#decimal',
    arity: 1,
    description: 'math:decimal(x) is true if x is a decimal (not integer)',
    apply: (x) => !Number.isInteger(Number(getValue(x)))
  },

// --- Additional String Builtins ---
  {
    uri: 'http://www.w3.org/2000/10/swap/string#substring',
    arity: 3,
    description: 'string:substring(s, start, len) returns substring',
    apply: (s, start, len) => {
      const str = String(getValue(s));
      return { type: 'Literal', value: str.substr(Number(getValue(start)), Number(getValue(len))) };
    }
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/string#replace',
    arity: 3,
    description: 'string:replace(s, search, replace) returns s with search replaced by replace',
    apply: (s, search, replace) => {
      const str = String(getValue(s));
      return { type: 'Literal', value: str.replace(new RegExp(String(getValue(search)), 'g'), String(getValue(replace))) };
    }
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/string#matches',
    arity: 2,
    description: 'string:matches(s, pattern) is true if s matches regex pattern',
    apply: (s, pattern) => new RegExp(String(getValue(pattern))).test(String(getValue(s)))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/string#length',
    arity: 1,
    description: 'string:length(s) returns the length of s',
    apply: (s) => ({ type: 'Literal', value: String(String(getValue(s)).length) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/string#toLowerCase',
    arity: 1,
    description: 'string:toLowerCase(s) returns s in lower case',
    apply: (s) => ({ type: 'Literal', value: String(getValue(s)).toLowerCase() })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/string#toUpperCase',
    arity: 1,
    description: 'string:toUpperCase(s) returns s in upper case',
    apply: (s) => ({ type: 'Literal', value: String(getValue(s)).toUpperCase() })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/string#trim',
    arity: 1,
    description: 'string:trim(s) returns s with whitespace trimmed',
    apply: (s) => ({ type: 'Literal', value: String(getValue(s)).trim() })
  },

// --- Additional List Builtins ---
  {
    uri: 'http://www.w3.org/2000/10/swap/list#first',
    arity: 2,
    description: 'list:first(list, x) is true if x is the first element',
    apply: (list, x) => {
      if (typeof list === 'object' && 'type' in list && list.type === 'List' && Array.isArray(list.elements)) {
        return list.elements.length > 0 && getValue(list.elements[0]) === getValue(x);
      }
      return false;
    }
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/list#rest',
    arity: 2,
    description: 'list:rest(list, rest) returns the rest of the list after the first element',
    apply: (list, rest) => {
      if (typeof list === 'object' && 'type' in list && list.type === 'List' && Array.isArray(list.elements)) {
        return { type: 'List', elements: list.elements.slice(1) };
      }
      return false;
    }
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/list#append',
    arity: 2,
    description: 'list:append(list, x) returns a new list with x appended',
    apply: (list, x) => {
      if (typeof list === 'object' && 'type' in list && list.type === 'List' && Array.isArray(list.elements)) {
        return { type: 'List', elements: [...list.elements, x] };
      }
      return false;
    }
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/list#remove',
    arity: 2,
    description: 'list:remove(list, x) returns a new list with x removed',
    apply: (list, x) => {
      if (typeof list === 'object' && 'type' in list && list.type === 'List' && Array.isArray(list.elements)) {
        return { type: 'List', elements: list.elements.filter(e => getValue(e) !== getValue(x)) };
      }
      return false;
    }
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/list#reverse',
    arity: 1,
    description: 'list:reverse(list) returns a new list with elements reversed',
    apply: (list) => {
      if (typeof list === 'object' && 'type' in list && list.type === 'List' && Array.isArray(list.elements)) {
        return { type: 'List', elements: [...list.elements].reverse() };
      }
      return false;
    }
  },

// --- Additional Time Builtins ---
  {
    uri: 'http://www.w3.org/2000/10/swap/time#now',
    arity: 1,
    description: 'time:now(x) is true if x is the current ISO date string',
    apply: (x) => String(getValue(x)) === new Date().toISOString()
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/time#before',
    arity: 2,
    description: 'time:before(a, b) is true if a < b (date)',
    apply: (a, b) => new Date(getValue(a)) < new Date(getValue(b))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/time#after',
    arity: 2,
    description: 'time:after(a, b) is true if a > b (date)',
    apply: (a, b) => new Date(getValue(a)) > new Date(getValue(b))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/time#duration',
    arity: 3,
    description: 'time:duration(a, b, d) is true if d is the difference in ms between a and b',
    apply: (a, b, d) => Number(getValue(d)) === Math.abs(new Date(getValue(a)).getTime() - new Date(getValue(b)).getTime())
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/time#hour',
    arity: 2,
    description: 'time:hour(date, h) is true if date has hour h',
    apply: (date, h) => new Date(getValue(date)).getHours() === Number(getValue(h))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/time#minute',
    arity: 2,
    description: 'time:minute(date, m) is true if date has minute m',
    apply: (date, m) => new Date(getValue(date)).getMinutes() === Number(getValue(m))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/time#second',
    arity: 2,
    description: 'time:second(date, s) is true if date has second s',
    apply: (date, s) => new Date(getValue(date)).getSeconds() === Number(getValue(s))
  },

// --- Additional Logic Builtins ---
  {
    uri: 'http://www.w3.org/2000/10/swap/log#or',
    arity: 2,
    description: 'log:or(x, y) is true if x or y is true',
    apply: (x, y) => Boolean(getValue(x)) || Boolean(getValue(y))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/log#and',
    arity: 2,
    description: 'log:and(x, y) is true if both x and y are true',
    apply: (x, y) => Boolean(getValue(x)) && Boolean(getValue(y))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/log#xor',
    arity: 2,
    description: 'log:xor(x, y) is true if x and y differ',
    apply: (x, y) => Boolean(getValue(x)) !== Boolean(getValue(y))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/log#if',
    arity: 3,
    description: 'log:if(cond, then, else) returns then if cond is true, else else',
    apply: (cond, thenVal, elseVal) => Boolean(getValue(cond)) ? thenVal : elseVal
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/log#distinct',
    arity: 2,
    description: 'log:distinct(x, y) is true if x != y',
    apply: (x, y) => getValue(x) !== getValue(y)
  },

// --- Type/Conversion Builtins ---
  {
    uri: 'http://www.w3.org/2000/10/swap/type#isLiteral',
    arity: 1,
    description: 'type:isLiteral(x) is true if x is a literal',
    apply: (x) => typeof x === 'object' && 'type' in x && x.type === 'Literal'
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/type#isIRI',
    arity: 1,
    description: 'type:isIRI(x) is true if x is an IRI',
    apply: (x) => typeof x === 'object' && 'type' in x && x.type === 'IRI'
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/type#isBlank',
    arity: 1,
    description: 'type:isBlank(x) is true if x is a blank node',
    apply: (x) => typeof x === 'object' && 'type' in x && x.type === 'BlankNode'
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/type#toString',
    arity: 1,
    description: 'type:toString(x) returns x as string',
    apply: (x) => ({ type: 'Literal', value: String(getValue(x)) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/type#toNumber',
    arity: 1,
    description: 'type:toNumber(x) returns x as number literal',
    apply: (x) => ({ type: 'Literal', value: String(Number(getValue(x))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/type#toBoolean',
    arity: 1,
    description: 'type:toBoolean(x) returns x as boolean literal',
    apply: (x) => ({ type: 'Literal', value: String(Boolean(getValue(x))) })
  },

// --- Other Builtins ---
  {
    uri: 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type',
    arity: 2,
    description: 'rdf:type(x, y) is true if x is of type y (handled by triple matching)',
    apply: () => true
  },
  {
    uri: 'http://www.w3.org/2002/07/owl#sameAs',
    arity: 2,
    description: 'owl:sameAs(x, y) is true if x and y are the same',
    apply: (x, y) => getValue(x) === getValue(y)
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#isFinite',
    arity: 1,
    description: 'math:isFinite(x) is true if x is a finite number',
    apply: (x) => isFinite(Number(getValue(x)))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#isNaN',
    arity: 1,
    description: 'math:isNaN(x) is true if x is NaN',
    apply: (x) => isNaN(Number(getValue(x)))
  },
// N3LogicBuiltins.ts
// Core N3Logic built-in predicates: math, string, logical, list, etc. (npm package version)
import { N3Builtin, N3Term } from './N3LogicTypes';

export const N3LogicBuiltins: N3Builtin[] = [
  // Math
  {
    uri: 'http://www.w3.org/2000/10/swap/math#greaterThan',
    arity: 2,
    description: 'math:greaterThan(x, y) is true if x > y',
    apply: (x, y) => Number(getValue(x)) > Number(getValue(y))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#lessThan',
    arity: 2,
    description: 'math:lessThan(x, y) is true if x < y',
    apply: (x, y) => Number(getValue(x)) < Number(getValue(y))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#equalTo',
    arity: 2,
    description: 'math:equalTo(x, y) is true if x == y',
    apply: (x, y) => getValue(x) == getValue(y)
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#notEqualTo',
    arity: 2,
    description: 'math:notEqualTo(x, y) is true if x != y',
    apply: (x, y) => getValue(x) != getValue(y)
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#sum',
    arity: 2,
    description: 'math:sum(x, y) returns x + y',
    apply: (x, y) => ({ type: 'Literal', value: String(Number(getValue(x)) + Number(getValue(y))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#difference',
    arity: 2,
    description: 'math:difference(x, y) returns x - y',
    apply: (x, y) => ({ type: 'Literal', value: String(Number(getValue(x)) - Number(getValue(y))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#product',
    arity: 2,
    description: 'math:product(x, y) returns x * y',
    apply: (x, y) => ({ type: 'Literal', value: String(Number(getValue(x)) * Number(getValue(y))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#quotient',
    arity: 2,
    description: 'math:quotient(x, y) returns x / y',
    apply: (x, y) => ({ type: 'Literal', value: String(Number(getValue(x)) / Number(getValue(y))) })
  },
  // String
  {
    uri: 'http://www.w3.org/2000/10/swap/string#concatenation',
    arity: 2,
    description: 'string:concatenation(x, y) returns x + y',
    apply: (x, y) => String(getValue(x)) + String(getValue(y))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/string#contains',
    arity: 2,
    description: 'string:contains(x, y) is true if x contains y',
    apply: (x, y) => String(getValue(x)).includes(String(getValue(y)))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/string#startsWith',
    arity: 2,
    description: 'string:startsWith(x, y) is true if x starts with y',
    apply: (x, y) => String(getValue(x)).startsWith(String(getValue(y)))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/string#endsWith',
    arity: 2,
    description: 'string:endsWith(x, y) is true if x ends with y',
    apply: (x, y) => String(getValue(x)).endsWith(String(getValue(y)))
  },
  // Logic
  {
    uri: 'http://www.w3.org/2000/10/swap/log#not',
    arity: 1,
    description: 'log:not(x) is true if x is false',
    apply: (x) => !getValue(x)
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/log#implies',
    arity: 2,
    description: 'log:implies(x, y) is true if x implies y (handled by rule engine)',
    apply: () => true
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/log#equalTo',
    arity: 2,
    description: 'log:equalTo(x, y) is true if x === y',
    apply: (x, y) => getValue(x) === getValue(y)
  },
  // List
  {
    uri: 'http://www.w3.org/2000/10/swap/list#length',
    arity: 2,
    description: 'list:length(list, n) is true if list has length n',
    apply: (list, n) => {
      if (typeof list === 'object' && 'type' in list && list.type === 'List' && Array.isArray(list.elements)) {
        return list.elements.length === Number(getValue(n));
      }
      return false;
    }
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/list#contains',
    arity: 2,
    description: 'list:contains(list, x) is true if list contains x',
    apply: (list, x) => {
      if (typeof list === 'object' && 'type' in list && list.type === 'List' && Array.isArray(list.elements)) {
        return list.elements.some(e => getValue(e) === getValue(x));
      }
      return false;
    }
  },
  // Time
  {
    uri: 'http://www.w3.org/2000/10/swap/time#year',
    arity: 2,
    description: 'time:year(date, y) is true if date has year y',
    apply: (date, y) => {
      const d = new Date(getValue(date));
      return d.getFullYear() === Number(getValue(y));
    }
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/time#month',
    arity: 2,
    description: 'time:month(date, m) is true if date has month m (1-12)',
    apply: (date, m) => {
      const d = new Date(getValue(date));
      return d.getMonth() + 1 === Number(getValue(m));
    }
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/time#day',
    arity: 2,
    description: 'time:day(date, d) is true if date has day d',
    apply: (date, d) => {
      const dt = new Date(getValue(date));
      return dt.getDate() === Number(getValue(d));
    }
  },
  // Comparison
  {
    uri: 'http://www.w3.org/2000/10/swap/math#greaterThanOrEqualTo',
    arity: 2,
    description: 'math:greaterThanOrEqualTo(x, y) is true if x >= y',
    apply: (x, y) => Number(getValue(x)) >= Number(getValue(y))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#lessThanOrEqualTo',
    arity: 2,
    description: 'math:lessThanOrEqualTo(x, y) is true if x <= y',
    apply: (x, y) => Number(getValue(x)) <= Number(getValue(y))
  },

  // --- Additional Math Builtins ---
  {
    uri: 'http://www.w3.org/2000/10/swap/math#abs',
    arity: 1,
    description: 'math:abs(x) returns the absolute value of x',
    apply: (x) => ({ type: 'Literal', value: String(Math.abs(Number(getValue(x)))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#power',
    arity: 2,
    description: 'math:power(x, y) returns x^y',
    apply: (x, y) => ({ type: 'Literal', value: String(Math.pow(Number(getValue(x)), Number(getValue(y)))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#modulo',
    arity: 2,
    description: 'math:modulo(x, y) returns x % y',
    apply: (x, y) => ({ type: 'Literal', value: String(Number(getValue(x)) % Number(getValue(y))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#floor',
    arity: 1,
    description: 'math:floor(x) returns the largest integer <= x',
    apply: (x) => ({ type: 'Literal', value: String(Math.floor(Number(getValue(x)))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#ceil',
    arity: 1,
    description: 'math:ceil(x) returns the smallest integer >= x',
    apply: (x) => ({ type: 'Literal', value: String(Math.ceil(Number(getValue(x)))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#round',
    arity: 1,
    description: 'math:round(x) returns the nearest integer to x',
    apply: (x) => ({ type: 'Literal', value: String(Math.round(Number(getValue(x)))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#negation',
    arity: 1,
    description: 'math:negation(x) returns -x',
    apply: (x) => ({ type: 'Literal', value: String(-Number(getValue(x))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#integer',
    arity: 1,
    description: 'math:integer(x) is true if x is an integer',
    apply: (x) => Number.isInteger(Number(getValue(x)))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#decimal',
    arity: 1,
    description: 'math:decimal(x) is true if x is a decimal (not integer)',
    apply: (x) => !Number.isInteger(Number(getValue(x)))
  },

  // --- Additional String Builtins ---
  {
    uri: 'http://www.w3.org/2000/10/swap/string#substring',
    arity: 3,
    description: 'string:substring(s, start, len) returns substring',
    apply: (s, start, len) => {
      const str = String(getValue(s));
      return { type: 'Literal', value: str.substr(Number(getValue(start)), Number(getValue(len))) };
    }
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/string#replace',
    arity: 3,
    description: 'string:replace(s, search, replace) returns s with search replaced by replace',
    apply: (s, search, replace) => {
      const str = String(getValue(s));
      return { type: 'Literal', value: str.replace(new RegExp(String(getValue(search)), 'g'), String(getValue(replace))) };
    }
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/string#matches',
    arity: 2,
    description: 'string:matches(s, pattern) is true if s matches regex pattern',
    apply: (s, pattern) => new RegExp(String(getValue(pattern))).test(String(getValue(s)))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/string#length',
    arity: 1,
    description: 'string:length(s) returns the length of s',
    apply: (s) => ({ type: 'Literal', value: String(String(getValue(s)).length) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/string#toLowerCase',
    arity: 1,
    description: 'string:toLowerCase(s) returns s in lower case',
    apply: (s) => ({ type: 'Literal', value: String(getValue(s)).toLowerCase() })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/string#toUpperCase',
    arity: 1,
    description: 'string:toUpperCase(s) returns s in upper case',
    apply: (s) => ({ type: 'Literal', value: String(getValue(s)).toUpperCase() })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/string#trim',
    arity: 1,
    description: 'string:trim(s) returns s with whitespace trimmed',
    apply: (s) => ({ type: 'Literal', value: String(getValue(s)).trim() })
  },

  // --- Additional List Builtins ---
  {
    uri: 'http://www.w3.org/2000/10/swap/list#first',
    arity: 2,
    description: 'list:first(list, x) is true if x is the first element',
    apply: (list, x) => {
      if (typeof list === 'object' && 'type' in list && list.type === 'List' && Array.isArray(list.elements)) {
        return list.elements.length > 0 && getValue(list.elements[0]) === getValue(x);
      }
      return false;
    }
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/list#rest',
    arity: 2,
    description: 'list:rest(list, rest) returns the rest of the list after the first element',
    apply: (list, rest) => {
      if (typeof list === 'object' && 'type' in list && list.type === 'List' && Array.isArray(list.elements)) {
        return { type: 'List', elements: list.elements.slice(1) };
      }
      return false;
    }
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/list#append',
    arity: 2,
    description: 'list:append(list, x) returns a new list with x appended',
    apply: (list, x) => {
      if (typeof list === 'object' && 'type' in list && list.type === 'List' && Array.isArray(list.elements)) {
        return { type: 'List', elements: [...list.elements, x] };
      }
      return false;
    }
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/list#remove',
    arity: 2,
    description: 'list:remove(list, x) returns a new list with x removed',
    apply: (list, x) => {
      if (typeof list === 'object' && 'type' in list && list.type === 'List' && Array.isArray(list.elements)) {
        return { type: 'List', elements: list.elements.filter(e => getValue(e) !== getValue(x)) };
      }
      return false;
    }
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/list#reverse',
    arity: 1,
    description: 'list:reverse(list) returns a new list with elements reversed',
    apply: (list) => {
      if (typeof list === 'object' && 'type' in list && list.type === 'List' && Array.isArray(list.elements)) {
        return { type: 'List', elements: [...list.elements].reverse() };
      }
      return false;
    }
  },

  // --- Additional Time Builtins ---
  {
    uri: 'http://www.w3.org/2000/10/swap/time#now',
    arity: 1,
    description: 'time:now(x) is true if x is the current ISO date string',
    apply: (x) => String(getValue(x)) === new Date().toISOString()
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/time#before',
    arity: 2,
    description: 'time:before(a, b) is true if a < b (date)',
    apply: (a, b) => new Date(getValue(a)) < new Date(getValue(b))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/time#after',
    arity: 2,
    description: 'time:after(a, b) is true if a > b (date)',
    apply: (a, b) => new Date(getValue(a)) > new Date(getValue(b))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/time#duration',
    arity: 3,
    description: 'time:duration(a, b, d) is true if d is the difference in ms between a and b',
    apply: (a, b, d) => Number(getValue(d)) === Math.abs(new Date(getValue(a)).getTime() - new Date(getValue(b)).getTime())
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/time#hour',
    arity: 2,
    description: 'time:hour(date, h) is true if date has hour h',
    apply: (date, h) => new Date(getValue(date)).getHours() === Number(getValue(h))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/time#minute',
    arity: 2,
    description: 'time:minute(date, m) is true if date has minute m',
    apply: (date, m) => new Date(getValue(date)).getMinutes() === Number(getValue(m))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/time#second',
    arity: 2,
    description: 'time:second(date, s) is true if date has second s',
    apply: (date, s) => new Date(getValue(date)).getSeconds() === Number(getValue(s))
  },

  // --- Additional Logic Builtins ---
  {
    uri: 'http://www.w3.org/2000/10/swap/log#or',
    arity: 2,
    description: 'log:or(x, y) is true if x or y is true',
    apply: (x, y) => Boolean(getValue(x)) || Boolean(getValue(y))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/log#and',
    arity: 2,
    description: 'log:and(x, y) is true if both x and y are true',
    apply: (x, y) => Boolean(getValue(x)) && Boolean(getValue(y))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/log#xor',
    arity: 2,
    description: 'log:xor(x, y) is true if x and y differ',
    apply: (x, y) => Boolean(getValue(x)) !== Boolean(getValue(y))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/log#if',
    arity: 3,
    description: 'log:if(cond, then, else) returns then if cond is true, else else',
    apply: (cond, thenVal, elseVal) => Boolean(getValue(cond)) ? thenVal : elseVal
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/log#distinct',
    arity: 2,
    description: 'log:distinct(x, y) is true if x != y',
    apply: (x, y) => getValue(x) !== getValue(y)
  },

  // --- Type/Conversion Builtins ---
  {
    uri: 'http://www.w3.org/2000/10/swap/type#isLiteral',
    arity: 1,
    description: 'type:isLiteral(x) is true if x is a literal',
    apply: (x) => typeof x === 'object' && 'type' in x && x.type === 'Literal'
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/type#isIRI',
    arity: 1,
    description: 'type:isIRI(x) is true if x is an IRI',
    apply: (x) => typeof x === 'object' && 'type' in x && x.type === 'IRI'
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/type#isBlank',
    arity: 1,
    description: 'type:isBlank(x) is true if x is a blank node',
    apply: (x) => typeof x === 'object' && 'type' in x && x.type === 'BlankNode'
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/type#toString',
    arity: 1,
    description: 'type:toString(x) returns x as string',
    apply: (x) => ({ type: 'Literal', value: String(getValue(x)) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/type#toNumber',
    arity: 1,
    description: 'type:toNumber(x) returns x as number literal',
    apply: (x) => ({ type: 'Literal', value: String(Number(getValue(x))) })
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/type#toBoolean',
    arity: 1,
    description: 'type:toBoolean(x) returns x as boolean literal',
    apply: (x) => ({ type: 'Literal', value: String(Boolean(getValue(x))) })
  },

  // --- Other Builtins ---
  {
    uri: 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type',
    arity: 2,
    description: 'rdf:type(x, y) is true if x is of type y (handled by triple matching)',
    apply: () => true
  },
  {
    uri: 'http://www.w3.org/2002/07/owl#sameAs',
    arity: 2,
    description: 'owl:sameAs(x, y) is true if x and y are the same',
    apply: (x, y) => getValue(x) === getValue(y)
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#isFinite',
    arity: 1,
    description: 'math:isFinite(x) is true if x is a finite number',
    apply: (x) => isFinite(Number(getValue(x)))
  },
  {
    uri: 'http://www.w3.org/2000/10/swap/math#isNaN',
    arity: 1,
    description: 'math:isNaN(x) is true if x is NaN',
    apply: (x) => isNaN(Number(getValue(x)))
  }
];

// Helper to extract value from N3Term
function getValue(term: N3Term): any {
  if (typeof term === 'object' && 'value' in term) return term.value;
  if (typeof term === 'object' && 'elements' in term) return term.elements;
  return term;
}
