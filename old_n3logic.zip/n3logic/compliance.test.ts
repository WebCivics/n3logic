// n3logic/compliance.test.ts
// Test suite for N3/N3Logic syntax compliance and edge cases
import { N3LogicParser } from './N3LogicParser';

describe('N3/N3Logic Syntax Compliance', () => {
  const parser = new N3LogicParser();

  it('parses IRIs, literals, variables, blank nodes, lists', () => {
    const n3 = `
      <a> <b> <c> .
      <a> <b> "literal" .
      <a> <b> ?x .
      <a> <b> _:b1 .
      <a> <b> ( <c> ?x "literal" ) .
    `;
    const doc = parser.parse(n3);
    expect(doc.triples.length).toBe(5);
  });

  it('parses rules with nested formulas and quantifiers', () => {
    const n3 = `@forAll ?x . { <a> <b> ?x } => { <c> <d> ?x } .`;
    const doc = parser.parse(n3);
    expect(doc.rules.length).toBe(1);
    expect(doc.rules[0].antecedent.quantifiers?.length).toBeGreaterThanOrEqual(0);
  });

  // Add more edge case tests as needed
});
