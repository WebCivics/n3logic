// N3LogicReasoner.ts
// N3Logic Reasoner: applies rules and built-ins to perform inference (npm package version)
import { N3LogicDocument, N3Triple, N3Term } from './N3LogicTypes';
import { N3LogicParser } from './N3LogicParser';
import { N3LogicBuiltins } from './N3LogicBuiltins';

export class N3LogicReasoner {
  private document: N3LogicDocument = { triples: [], rules: [], builtins: [] };
  private raw: string = '';

  loadOntology(data: string, format: string): void {
    if (format !== 'n3' && format !== 'n3logic') {
      throw new Error('Only N3/N3Logic format supported in N3LogicReasoner');
    }
    this.raw = data;
    const parser = new N3LogicParser();
    this.document = parser.parse(data);
    this.document.builtins = [...(this.document.builtins || []), ...N3LogicBuiltins];
  }

  reason(): object {
    let inferred: Set<string> = new Set();
    let working: N3Triple[] = [...this.document.triples];
    for (const t of working) inferred.add(this.tripleToString(t));
    let changed = true;
    while (changed) {
      changed = false;
      for (const rule of this.document.rules) {
        const bindingsList = this.matchFormula(rule.antecedent, working);
        for (const bindings of bindingsList) {
          if (!this.evaluateBuiltins(rule.antecedent.triples, bindings)) continue;
          for (const consTriple of rule.consequent.triples) {
            const instantiated = this.instantiateTriple(consTriple, bindings);
            const key = this.tripleToString(instantiated);
            if (!inferred.has(key)) {
              inferred.add(key);
              working.push(instantiated);
              changed = true;
            }
          }
        }
      }
    }
    return {
      message: 'N3Logic reasoning: forward chaining with built-in, quantifier, and formula evaluation',
      triples: Array.from(inferred).map(this.stringToTriple),
      rules: this.document.rules,
      builtins: this.document.builtins
    };
  }

  private matchFormula(formula: any, data: N3Triple[]): Array<Record<string, N3Term>> {
    if (!formula) return [{}];
    if (formula.type === 'Formula') {
      return this.matchAntecedent(formula.triples, data);
    } else if (formula.type === 'ForAll') {
      return this.matchFormula(formula.formula, data);
    } else if (formula.type === 'Exists') {
      return this.matchFormula(formula.formula, data);
    }
    return [{}];
  }

  private matchAntecedent(patterns: N3Triple[], data: N3Triple[]): Array<Record<string, N3Term>> {
    if (patterns.length === 0) return [{}];
    const [first, ...rest] = patterns;
    const results: Array<Record<string, N3Term>> = [];
    for (const triple of data) {
      const bindings = this.matchTriple(first, triple);
      if (bindings) {
        const restBindingsList = this.matchAntecedent(rest, data);
        for (const restBindings of restBindingsList) {
          let compatible = true;
          for (const k in bindings) {
            if (k in restBindings && !this.termEquals(bindings[k], restBindings[k])) {
              compatible = false;
              break;
            }
          }
          if (compatible) {
            results.push({ ...restBindings, ...bindings });
          }
        }
      }
    }
    return results;
  }

  private matchTriple(pattern: N3Triple, triple: N3Triple): Record<string, N3Term> | null {
    const bindings: Record<string, N3Term> = {};
    if (!this.termMatch(pattern.subject, triple.subject, bindings)) return null;
    if (!this.termMatch(pattern.predicate, triple.predicate, bindings)) return null;
    if (!this.termMatch(pattern.object, triple.object, bindings)) return null;
    return bindings;
  }

  private termMatch(pattern: N3Term, value: N3Term, bindings: Record<string, N3Term>): boolean {
    if (typeof pattern === 'object' && 'type' in pattern && pattern.type === 'Variable') {
      const varName = pattern.value;
      if (varName in bindings) {
        return this.termEquals(bindings[varName], value);
      } else {
        bindings[varName] = value;
        return true;
      }
    } else {
      return this.termEquals(pattern, value);
    }
  }

  private termEquals(a: N3Term, b: N3Term): boolean {
    if (typeof a === 'string' && typeof b === 'string') return a === b;
    if (typeof a === 'object' && typeof b === 'object' && 'value' in a && 'value' in b) return a.value === b.value;
    return false;
  }

  private evaluateBuiltins(triples: N3Triple[], bindings: Record<string, N3Term>): boolean {
    for (const triple of triples) {
      const builtin = this.document.builtins?.find(b =>
        typeof triple.predicate === 'object' && 'value' in triple.predicate && b.uri === triple.predicate.value
      );
      if (builtin) {
        const args = [triple.subject, triple.object].map(term =>
          (typeof term === 'object' && 'type' in term && term.type === 'Variable') ? (bindings[term.value] ?? term) : term
        );
        const result = builtin.apply(...args);
        if (result !== true) return false;
      }
    }
    return true;
  }

  private instantiateTriple(pattern: N3Triple, bindings: Record<string, N3Term>): N3Triple {
    return {
      subject: this.instantiateTerm(pattern.subject, bindings),
      predicate: this.instantiateTerm(pattern.predicate, bindings),
      object: this.instantiateTerm(pattern.object, bindings)
    };
  }

  private instantiateTerm(term: N3Term, bindings: Record<string, N3Term>): N3Term {
    if (typeof term === 'object' && 'type' in term && term.type === 'Variable') {
      return bindings[term.value] ?? term;
    }
    return term;
  }

  private tripleToString(triple: N3Triple): string {
    return `${this.termToString(triple.subject)} ${this.termToString(triple.predicate)} ${this.termToString(triple.object)}`;
  }

  private stringToTriple = (str: string): N3Triple => {
    const [s, p, o] = str.split(' ');
    return {
      subject: { type: 'IRI', value: s },
      predicate: { type: 'IRI', value: p },
      object: { type: 'IRI', value: o }
    };
  };

  private termToString(term: N3Term): string {
    if (typeof term === 'string') return term;
    if ('value' in term) return term.value;
    return '';
  }
}
